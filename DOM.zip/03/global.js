function myFunction() {
  var x = document.getElementById("show");
  x.style.display = "block";
}
